module.exports = app => {
  const bidcontroller = require("../../controller/bidcontroller");

  app.post("/api/bid", bidcontroller.createabid);
  app.get("/api/bid/:id", bidcontroller.getadatabybiderID);
  app.get("/api/client/bid/:id", bidcontroller.ChakeBedding);
  app.get("/app/getbids/creator/:id", bidcontroller.getmyPostBids);
  app.delete("/api/deletBid/:id", bidcontroller.deletthisbid);
  app.post("/api/assigJob/:id", bidcontroller.assignJob);
};
