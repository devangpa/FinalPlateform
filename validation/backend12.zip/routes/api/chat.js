module.exports = app => {
  const chatcontroller = require("../../controller/chatcontroller");
  app.post("/postchatmessage", chatcontroller.savechatdata);
  app.post("/getchatdata", chatcontroller.getchatbyID);
};
