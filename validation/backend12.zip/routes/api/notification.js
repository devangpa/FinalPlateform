module.exports = app => {
  const notificationcontroller = require("../../controller/NotificationController");

  app.get("/api/notification/:id", notificationcontroller.GetNotificationbyid);
};
