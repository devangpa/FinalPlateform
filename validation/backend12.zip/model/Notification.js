const mongoose = require("mongoose");

// Create Schema
const NotificationSchema = mongoose.Schema({
  NotificationUserId: {
    type: String,
    require: true
  },
  NotificationMessage: {
    type: String,
    require: true
  },

  date: {
    type: Date,
    default: Date.now
  }
});
module.exports = mongoose.model("notification", NotificationSchema);
