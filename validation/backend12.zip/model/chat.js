const mongoose = require("mongoose");

// Create Schema
const Chat = mongoose.Schema({
  SenderuserName: {
    type: String,
    require: true
  },
  senderuserid: {
    type: String,
    require: true
  },
  ReciverUsername: {
    type: String,
    require: true
  },
  ReciverUserid: {
    type: String,
    require: true
  },
  Message: {
    type: String,
    require: true
  },
  date: {
    type: Date,
    default: Date.now
  }
});
module.exports = mongoose.model("chat", Chat);
