const notification = require("../model/Notification");

exports.GetNotificationbyid = async (req, res) => {
  const Id = req.params.id;

  let findObj = await { NotificationUserId: Id };
  try {
    console.log(findObj);
    const getObj = await notification.find(findObj);
    console.log(getObj);
    res.status(200).send({ message: "available", data: getObj });
  } catch (error) {
    res.status(400).send({ message: "No notification available" });
  }
};
