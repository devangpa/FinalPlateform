const bid = require("../model/Biding");
const job = require("../model/Job");
const user = require("../model/User");
const notification = require("../model/Notification");
const AssigJOb = require("../model/AssignJob");
var nodemailer = require("nodemailer");
var transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "rs2321994@gmail.com",
    pass: "Devang@8688"
  }
});

exports.createabid = async (req, res) => {
  const data = req.body;

  try {
    let BidderObj = { _id: data.BiderUserID };
    let JobqueryObj = { _id: data.Bidingpostid };
    const FindJJobobj = await job.findById(data.Bidingpostid);
    const biddderUser = await user.findById(data.BiderUserID);

    data["BiderUsername"] = biddderUser.name;
    data["jobTitle"] = FindJJobobj.jobtitle;
    console.log(data);

    const savebeed = await bid.create(data);

    let JobcraetorObj = { _id: savebeed.jobcreatoruserID };

    const jobcreatorUser = await user.findById(savebeed.jobcreatoruserID);

    const notificationObj = {
      NotificationUserId: savebeed.jobcreatoruserID,
      NotificationMessage: `you get Bid from ${biddderUser.name}`
    };

    const Notificationcreator = await notification.create(notificationObj);

    const mailOptions = {
      from: "rs2321994@gmail.com", // sender address
      to: "fasdasdasdasd@fsdf.sdfds", // list of receivers     jobcreatorUser.email
      subject: `Regarding Your Post For ${FindJJobobj.jobtitle}`, // Subject line
      html: `<p>Dear User , On Your Requirnment ${biddderUser.name} Would Like to Do Work On${savebeed.BidingPrice} </p>` // plain text body
    };

    const sendmail = await transporter.sendMail(mailOptions);

    // const savebeed = await bid.create();

    // {
    //     "Bidingpostid":"5f23df5229cf0120a8a4c946",
    //     "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ":"5f15362038097d33cce92c90",
    //     "BidingDescription":"asdasdasdasasdasdasdasdasd",
    //     "BidingPrice":"65",
    //     "jobposteduserID":"5f191836568121324c7a577c"
    // }
    res.status(200).send({ Message: "Sucesfully BId sucessfull" }); // data: savebeed
  } catch (err) {
    res
      .status(400)
      .send({ Message: "Not Able to Bid On this Project", data: err });
  }
};

exports.getadatabybiderID = async (req, res) => {
  const ID = req.params.id;
  const findObj = { BiderUserID: ID };
  try {
    const Data = await bid.find(findObj);
    res.status(200).send({ Message: "SucessFully Fetched a data", data: Data });
  } catch (err) {
    res
      .status(400)
      .send({ Message: "Not Able to Bid On this Project", data: err });
  }
};
exports.ChakeBedding = async (req, res) => {
  console.log(req.params.id);
  const ID = req.params.id;
  const findObj = { jobposteduserID: ID };
  //data which is send by JOB ID
  try {
    const Data = await bid.find(findObj);

    res.status(200).send({ Message: "SucessFully Fetched a data", data: Data });
  } catch (err) {
    res
      .status(400)
      .send({ Message: "Not Able to Bid On this Project", data: err });
  }
};

exports.getmyPostBids = async (req, res) => {
  const ID = req.params.id;
  const FindingObj = { jobcreatoruserID: ID };
  try {
    const Data = await bid.find(FindingObj);

    res.status(200).send({ Message: "SucessFully Fetched a data", data: Data });
  } catch (err) {
    res.status(400).send({ Message: "Not Able to Find ANy Bid", data: err });
  }
};

exports.deletthisbid = async (req, res) => {
  const ID = req.params.id;

  try {
    const Data = await bid.findByIdAndDelete(ID);

    res.status(200).send({ Message: "DeletedSucessFull" });
  } catch (err) {
    res.status(400).send({ Message: "Not Able Delet", data: err });
  }
};

exports.assignJob = async (req, res) => {
  try {
    const ID = req.params.id;

    let Jobdata = await bid.findById(ID);

    let assignuserid = Jobdata.BiderUserID;
    const assignUser = await user.findById(assignuserid); //bidder Detail
    //Send NOtification To The Bidder

    let JobcreatorUserID = Jobdata.jobcreatoruserID; //jobcreator Detail
    const Jobcreator = await user.findById(JobcreatorUserID);
    console.log(Jobcreator);

    //
    let assignJobObj = {
      JobID: Jobdata._id,
      JobcreatorUserID: JobcreatorUserID,
      JobcreatorUserName: Jobcreator.name,
      JobAssigntoUserID: assignuserid,
      JobAssigntoUserName: assignUser.name
    };

    const JobAssign = await AssigJOb.create(assignJobObj);
    // const deletJObfromFormtend = await job.findByIdAndDelete(
    //   Jobdata.Bidingpostid
    // ); // Delet Job from front EndOnce Assign To User

    // const DeletFrombedding = await bid.deleteOne({
    //   Bidingpostid: Jobdata.Bidingpostid,
    // });

    // console.log(JobAssign);

    res
      .status(200)
      .send({ Message: "Assign Job Sucessfully", data: JobAssign });
  } catch (err) {
    res.status(400).send({ Message: "Not Able to assign", data: err });
  }
};
